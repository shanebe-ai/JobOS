// JobOS Scraper - Background Script

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "save_job") {
        saveJob(request.data)
            .then(result => sendResponse(result))
            .catch(error => sendResponse({ success: false, error: error.message }));
        return true; // Keep the message channel open for async response
    }
});

async function saveJob(jobData) {
    try {
        console.log('Sending job to JobOS:', jobData);
        const response = await fetch('http://37.27.80.77:3002/api/jobs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(jobData)
        });

        if (!response.ok) {
            throw new Error(`Server error: ${response.status} ${response.statusText}`);
        }

        const result = await response.json();
        return { success: true, data: result };
    } catch (error) {
        console.error('Error saving job:', error);
        return { success: false, error: error.message };
    }
}
