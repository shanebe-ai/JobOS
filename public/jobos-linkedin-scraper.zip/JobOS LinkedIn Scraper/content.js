// JobOS Scraper - Content Script (Debug Version)

function scrapeJobDetails() {
    console.log('JobOS Scraper: Starting scrape...');

    // STRATEGY 0: JSON-LD (The Gold Standard)
    try {
        const scripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (const script of scripts) {
            try {
                const data = JSON.parse(script.innerText);
                if (data['@type'] === 'JobPosting') {
                    console.log('JobOS: Found JSON-LD Job data!', data);

                    let loc = '';
                    if (data.jobLocation) {
                        if (data.jobLocation.address) {
                            const addr = data.jobLocation.address;
                            if (addr.addressLocality && addr.addressCountry) {
                                loc = `${addr.addressLocality}, ${addr.addressCountry}`;
                            } else if (addr.addressCountry) {
                                loc = addr.addressCountry;
                            } else if (typeof addr === 'string') {
                                loc = addr;
                            }
                        }
                        if (!loc && data.jobLocation.description) {
                            loc = data.jobLocation.description;
                        }
                    }

                    if (data.applicantLocationRequirements && data.applicantLocationRequirements['@type'] === 'Country') {
                        if (loc) loc += ' (Remote)';
                        else loc = `${data.applicantLocationRequirements.name} (Remote)`;
                    }

                    if (loc && data.jobLocationType === 'TELECOMMUTE' && !loc.includes('Remote')) {
                        loc += ' (Remote)';
                    }

                    return {
                        title: data.title,
                        company: data.hiringOrganization?.name || '',
                        location: loc,
                        description: data.description,
                        url: window.location.href,
                        scrapedAt: new Date().toISOString(),
                        source: 'json-ld'
                    };
                }
            } catch (inner) { }
        }
    } catch (e) {
        console.log('JSON-LD parse failed', e);
    }

    // --- FALLBACK: VISUAL SCRAPING ---

    let location = '';
    let company = '';
    let title = '';

    // Try standard selectors first
    const selectors = {
        title: ['h1', '.job-details-jobs-unified-top-card__job-title', '.top-card-layout__title'],
    };

    const getText = (list) => {
        for (const s of list) {
            const els = document.querySelectorAll(s);
            console.log(`Trying selector "${s}": found ${els.length} elements`);
            for (const el of els) {
                if (el && el.innerText.trim()) {
                    console.log(`  -> Got text: "${el.innerText.trim()}"`);
                    return el.innerText.trim();
                }
            }
        }
        return '';
    };

    title = getText(selectors.title) || document.title.split('|')[0].trim();
    console.log("Final title:", title);

    // Company: Look for link to /company/ page
    const companyLinks = document.querySelectorAll('a[href*="/company/"]');
    console.log(`Found ${companyLinks.length} links to /company/ pages`);
    for (const link of companyLinks) {
        const text = link.innerText.trim();
        if (text && text.length > 0 && text.length < 100 && !text.includes('\n')) {
            company = text;
            console.log(`Found company from link: "${company}"`);
            break;
        }
    }
    console.log("Final company:", company);

    // LOCATION & WORK TYPE extraction
    let workType = '';

    // Strategy 1: Look for the job info container with location
    // LinkedIn typically shows: "Location · Time posted · Applicants" pattern
    const jobInfoSelectors = [
        '.job-details-jobs-unified-top-card__primary-description-container',
        '.job-details-jobs-unified-top-card__tertiary-description',
        '.jobs-unified-top-card__primary-description',
        'p span._26397205'
    ];

    // Helper to split on various separators LinkedIn uses
    const splitOnSeparators = (text) => {
        // LinkedIn uses: " · " (middle dot), " • " (bullet), " - ", or newlines
        return text.split(/\s*[·•\-]\s*|\n/).map(p => p.trim()).filter(p => p.length > 0);
    };

    for (const selector of jobInfoSelectors) {
        const els = document.querySelectorAll(selector);
        for (const el of els) {
            const text = el.innerText.trim();
            if (text && text.length > 0) {
                // Split on various separators
                const parts = splitOnSeparators(text);
                if (parts.length > 0) {
                    // Look for the first part that looks like a location (not metadata)
                    const metadataPatterns = /^(Reposted|Posted|Over \d+|Promoted|Be an early|Easy Apply|\d+ applicant|Responses managed)/i;

                    for (const part of parts) {
                        if (!metadataPatterns.test(part) && part.length < 100 && part.length > 1) {
                            location = part;
                            console.log(`Found location: "${location}" from selector "${selector}"`);
                            break;
                        }
                    }
                    if (location) break;
                }
            }
        }
        if (location) break;
    }

    // Strategy 2: Look for standalone location elements
    if (!location) {
        const locationSelectors = [
            '.job-details-jobs-unified-top-card__bullet',
            '.jobs-unified-top-card__bullet'
        ];
        for (const selector of locationSelectors) {
            const el = document.querySelector(selector);
            if (el) {
                const parts = splitOnSeparators(el.innerText.trim());
                if (parts.length > 0 && parts[0].length < 100) {
                    location = parts[0];
                    console.log(`Found location from bullet: "${location}"`);
                    break;
                }
            }
        }
    }

    // Strategy 3: Scan page text AFTER the title+company to find location
    if (!location) {
        const rawText = document.body.innerText || '';
        const lines = rawText.split('\n').map(l => l.trim()).filter(l => l.length > 0);

        const skipPatterns = /^(Skip|Home|Jobs|Sign|Join|Log|Search|Show|See|Follow|Connect|Save|Apply|Message|Easy Apply|Share|Report|Dismiss|Close|Back|Next|Previous|Promoted|Reposted|Posted|Over \d+|\d+ applicant|Responses|Be an early|LinkedIn|Notifications|Me|Work|Gaming)/i;

        // Location pattern: 1-4 capitalized words, optional comma-separated second part
        const locationPattern = /^[A-Z][a-zA-ZÀ-ÿ]{1,30}(?:\s[A-Z][a-zA-ZÀ-ÿ]{1,20}){0,2}(?:,\s*[A-Z][a-zA-ZÀ-ÿ]{1,30}(?:\s[A-Z][a-zA-ZÀ-ÿ]{1,20}){0,2})?$/;

        // Find where the company line appears — scan only after that
        const companyLineIndex = company
            ? lines.findIndex(l => l === company || l.startsWith(company))
            : -1;
        const startFrom = companyLineIndex >= 0 ? companyLineIndex + 1 : 0;

        // Only look at the next 10 lines after company — location is always nearby
        const searchWindow = lines.slice(startFrom, startFrom + 10);

        for (const line of searchWindow) {
            if (line === title || line === company) continue;
            if (skipPatterns.test(line)) continue;
            // Strip trailing metadata and re-test
            const firstPart = line.split(/\s*[·•]\s*/)[0].trim();
            if (!firstPart || firstPart.length > 60) continue;
            if (firstPart === title || firstPart === company) continue;
            if (skipPatterns.test(firstPart)) continue;
            if (locationPattern.test(firstPart) || firstPart === 'Remote' || firstPart === 'Worldwide') {
                location = firstPart;
                console.log(`Found location via post-company scan: "${location}"`);
                break;
            }
        }
    }

    // Extract work type from buttons or badges
    const workTypeButtons = document.querySelectorAll('button span, .job-details-jobs-unified-top-card__job-insight span');
    for (const btn of workTypeButtons) {
        const text = btn.innerText.trim();
        if (text === 'Remote' || text === 'Hybrid' || text === 'On-site') {
            workType = text;
            console.log(`Found work type: "${workType}"`);
            break;
        }
    }

    console.log("Final location:", location);
    console.log("Final work type:", workType);

    // DESCRIPTION - Extract HTML from job description section
    let description = '';

    // Find the "About the job" section and get its HTML content
    const h2Elements = document.querySelectorAll('h2');
    let descriptionContainer = null;

    for (const h2 of h2Elements) {
        if (h2.innerText.includes('About the job')) {
            // Get the parent container
            descriptionContainer = h2.parentElement;
            break;
        }
    }

    if (descriptionContainer) {
        // Find the description content (usually in a span or div after the h2)
        const descSpan = descriptionContainer.querySelector('span[class*="expandable"], div[class*="description"]');
        if (descSpan) {
            description = descSpan.innerHTML.trim();
            console.log(`JobOS: Extracted HTML description (${description.length} chars)`);
        }
    }

    // Fallback to text-based extraction if HTML method fails
    if (!description) {
        console.log('JobOS: Falling back to text extraction');
        const bodyText = document.body.innerText;
        const marker = "About the job";
        const markerIdx = bodyText.indexOf(marker);

        if (markerIdx !== -1) {
            let content = bodyText.substring(markerIdx + marker.length);
            const stopMarkers = ["About the company", "Similar jobs", "People also viewed"];
            let stopIdx = content.length;
            for (const stopMarker of stopMarkers) {
                const idx = content.indexOf(stopMarker);
                if (idx !== -1 && idx < stopIdx) {
                    stopIdx = idx;
                }
            }
            description = content.substring(0, stopIdx).trim();
            description = `<p>${description.replace(/\n/g, '<br>')}</p>`;
        }
    }

    console.log("=== FINAL RESULTS ===");
    console.log("Title:", title);
    console.log("Company:", company);
    console.log("Location:", location);
    console.log("Description length:", description.length);

    return {
        title: title || '',
        company: company || '',
        location: location || '',
        workType: workType || '',
        description: description || '',
        url: window.location.href,
        scrapedAt: new Date().toISOString(),
        source: 'visual-fallback'
    };
}

// Listen for messages 
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scrape") {
        sendResponse(scrapeJobDetails());
    }
});

// Check if current page is a scrapable job posting
function isScrapableJobPage() {
    const url = window.location.href;

    // Primary check: URL pattern - /jobs/view/ is the definitive job page pattern
    if (url.includes('/jobs/view/')) {
        console.log('JobOS: Detected /jobs/view/ URL, page is scrapable');
        return true;
    }

    // Secondary: collections page with a currentJobId parameter (job panel open)
    if (url.includes('/jobs/collections/') && url.includes('currentJobId')) {
        console.log('JobOS: Detected jobs collection with currentJobId, page is scrapable');
        return true;
    }

    // Tertiary: /jobs/search/ with currentJobId (search results with job panel)
    if (url.includes('/jobs/search/') && url.includes('currentJobId')) {
        console.log('JobOS: Detected jobs search with currentJobId, page is scrapable');
        return true;
    }

    console.log('JobOS: Not a job page URL, skipping');
    return false;
}

// Create and inject the floating button
function injectOverlay() {
    const existingBtn = document.getElementById('jobos-save-btn');

    // Remove existing button if page is no longer scrapable
    if (existingBtn && !isScrapableJobPage()) {
        existingBtn.remove();
        return;
    }

    // Don't inject if not a scrapable job page
    if (!isScrapableJobPage()) {
        return;
    }

    if (existingBtn) return;

    const btn = document.createElement('button');
    btn.id = 'jobos-save-btn';
    btn.innerHTML = '<span>+</span> Save to JobOS';

    Object.assign(btn.style, {
        position: 'fixed', bottom: '20px', right: '20px', zIndex: '9999',
        padding: '12px 24px', backgroundColor: '#0f172a', color: 'white',
        border: 'none', borderRadius: '50px', cursor: 'pointer',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)', fontSize: '14px', fontWeight: '600',
        display: 'flex', alignItems: 'center', gap: '8px',
        fontFamily: '-apple-system, system-ui, sans-serif'
    });

    btn.onclick = async () => {
        const originalText = btn.innerHTML;

        try { chrome.runtime.getURL(''); }
        catch (e) { alert("Please REFRESH (F5)"); return; }

        btn.innerText = 'Scanning...';
        btn.style.backgroundColor = '#64748b';

        try {
            const jobData = scrapeJobDetails();

            const descPreview = jobData.description
                ? jobData.description.replace(/<[^>]*>/g, '').substring(0, 80) + '...'
                : '(EMPTY)';

            const confirmMsg = `JobOS Found:\n\nTitle: ${jobData.title}\nCompany: ${jobData.company}\nLocation: ${jobData.location}\n\nDescription: ${jobData.description.length} chars\n"${descPreview}"\n\nSave?`;

            if (!confirm(confirmMsg)) {
                btn.innerHTML = originalText;
                btn.style.backgroundColor = '#0f172a';
                return;
            }

            if (!jobData.title) throw new Error("Missing Job Title");

            btn.innerText = 'Saving...';

            const response = await chrome.runtime.sendMessage({
                action: "save_job",
                data: jobData
            });

            if (response.success) {
                btn.innerHTML = response.data?.isDuplicate ? '<span>⚠️</span> Duplicate' : '<span>✓</span> Saved!';
                btn.style.backgroundColor = response.data?.isDuplicate ? '#eab308' : '#10b981';
                setTimeout(() => {
                    btn.innerHTML = originalText;
                    btn.style.backgroundColor = '#0f172a';
                }, 3000);
            } else {
                throw new Error(response.error || "Server error");
            }

        } catch (error) {
            console.error('JobOS Error:', error);
            btn.innerText = 'Error!';
            btn.style.backgroundColor = '#ef4444';
            alert(`Failed: ${error.message}\n\nCheck browser console (F12) for details.`);

            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.style.backgroundColor = '#0f172a';
            }, 3000);
        }
    };

    document.body.appendChild(btn);
}

// Retry injection until job content loads (LinkedIn is a SPA)
function tryInjectWithRetry(maxAttempts = 10, delay = 500) {
    let attempts = 0;

    function attempt() {
        attempts++;
        console.log(`JobOS: Injection attempt ${attempts}/${maxAttempts}`);

        const existingBtn = document.getElementById('jobos-save-btn');
        if (existingBtn) {
            console.log('JobOS: Button already exists');
            return;
        }

        if (isScrapableJobPage()) {
            injectOverlay();
            return;
        }

        if (attempts < maxAttempts) {
            setTimeout(attempt, delay);
        } else {
            console.log('JobOS: Max attempts reached, page may not be a job posting');
        }
    }

    attempt();
}

// Initial injection with retry
tryInjectWithRetry();

// Watch for URL changes (SPA navigation)
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        console.log('JobOS: URL changed to', url);
        // Remove existing button on navigation
        const existingBtn = document.getElementById('jobos-save-btn');
        if (existingBtn) existingBtn.remove();
        // Retry injection for new page
        tryInjectWithRetry();
    }
}).observe(document, { subtree: true, childList: true });
