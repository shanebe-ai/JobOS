document.addEventListener('DOMContentLoaded', () => {
    const scanBtn = document.getElementById('scanBtn');
    const statusDiv = document.getElementById('status');

    scanBtn.addEventListener('click', async () => {
        statusDiv.textContent = 'Scanning...';
        statusDiv.className = 'status';

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (!tab.url.includes('linkedin.com/jobs')) {
            statusDiv.textContent = 'Please navigate to a LinkedIn job page.';
            statusDiv.className = 'status error';
            return;
        }

        try {
            // First, ask content script to scrape
            const scrapeResult = await chrome.tabs.sendMessage(tab.id, { action: "scrape" });

            if (!scrapeResult) {
                throw new Error('Could not scrape page data');
            }

            statusDiv.textContent = 'Saving...';

            // Then, ask background script to save
            const saveResult = await chrome.runtime.sendMessage({
                action: "save_job",
                data: scrapeResult
            });

            if (saveResult.success) {
                statusDiv.textContent = 'Saved to JobOS!';
                statusDiv.style.color = '#10b981';
            } else {
                throw new Error(saveResult.error || 'Unknown error');
            }

        } catch (error) {
            statusDiv.textContent = 'Error: ' + error.message;
            statusDiv.className = 'status error';
        }
    });
});
