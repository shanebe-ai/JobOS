// LinkedIn for JobOS - Content Script

// ─── JOB SCRAPING ────────────────────────────────────────────────────────────

function scrapeJobDetails() {
    console.log('JobOS: Starting job scrape...');

    // STRATEGY 0: JSON-LD (The Gold Standard)
    try {
        const scripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (const script of scripts) {
            try {
                const data = JSON.parse(script.innerText);
                if (data['@type'] === 'JobPosting') {
                    let loc = '';
                    if (data.jobLocation) {
                        if (data.jobLocation.address) {
                            const addr = data.jobLocation.address;
                            if (addr.addressLocality && addr.addressCountry) loc = `${addr.addressLocality}, ${addr.addressCountry}`;
                            else if (addr.addressCountry) loc = addr.addressCountry;
                            else if (typeof addr === 'string') loc = addr;
                        }
                        if (!loc && data.jobLocation.description) loc = data.jobLocation.description;
                    }
                    if (data.applicantLocationRequirements?.['@type'] === 'Country') {
                        loc = loc ? `${loc} (Remote)` : `${data.applicantLocationRequirements.name} (Remote)`;
                    }
                    if (loc && data.jobLocationType === 'TELECOMMUTE' && !loc.includes('Remote')) loc += ' (Remote)';
                    return {
                        title: data.title, company: data.hiringOrganization?.name || '',
                        location: loc, description: data.description,
                        url: window.location.href, scrapedAt: new Date().toISOString(), source: 'json-ld'
                    };
                }
            } catch { }
        }
    } catch (e) { console.log('JSON-LD parse failed', e); }

    // FALLBACK: VISUAL SCRAPING
    let location = '', company = '', title = '', workType = '';

    const getText = (list) => {
        for (const s of list) {
            for (const el of document.querySelectorAll(s)) {
                if (el?.innerText?.trim()) return el.innerText.trim();
            }
        }
        return '';
    };

    title = getText(['h1', '.job-details-jobs-unified-top-card__job-title', '.top-card-layout__title']) || document.title.split('|')[0].trim();

    for (const link of document.querySelectorAll('a[href*="/company/"]')) {
        const text = link.innerText.trim();
        if (text && text.length < 100 && !text.includes('\n')) { company = text; break; }
    }

    const splitOnSep = (text) => text.split(/\s*[·•\-]\s*|\n/).map(p => p.trim()).filter(p => p.length > 0);

    for (const selector of ['.job-details-jobs-unified-top-card__primary-description-container', '.job-details-jobs-unified-top-card__tertiary-description', '.jobs-unified-top-card__primary-description']) {
        for (const el of document.querySelectorAll(selector)) {
            const parts = splitOnSep(el.innerText.trim());
            const skip = /^(Reposted|Posted|Over \d+|Promoted|Be an early|Easy Apply|\d+ applicant|Responses managed)/i;
            for (const part of parts) {
                if (!skip.test(part) && part.length < 100 && part.length > 1) { location = part; break; }
            }
            if (location) break;
        }
        if (location) break;
    }

    if (!location) {
        for (const selector of ['.job-details-jobs-unified-top-card__bullet', '.jobs-unified-top-card__bullet']) {
            const el = document.querySelector(selector);
            if (el) { const parts = splitOnSep(el.innerText.trim()); if (parts[0]?.length < 100) { location = parts[0]; break; } }
        }
    }

    if (!location) {
        const lines = (document.body.innerText || '').split('\n').map(l => l.trim()).filter(l => l.length > 0);
        const skip = /^(Skip|Home|Jobs|Sign|Join|Log|Search|Show|See|Follow|Connect|Save|Apply|Message|Easy Apply|Share|Report|Dismiss|Close|Back|Next|Previous|Promoted|Reposted|Posted|Over \d+|\d+ applicant|Responses|Be an early|LinkedIn|Notifications|Me|Work|Gaming)/i;
        const locPat = /^[A-Z][a-zA-ZÀ-ÿ]{1,30}(?:\s[A-Z][a-zA-ZÀ-ÿ]{1,20}){0,2}(?:,\s*[A-Z][a-zA-ZÀ-ÿ]{1,30}(?:\s[A-Z][a-zA-ZÀ-ÿ]{1,20}){0,2})?$/;
        const compIdx = company ? lines.findIndex(l => l === company || l.startsWith(company)) : -1;
        const window10 = lines.slice(compIdx >= 0 ? compIdx + 1 : 0, (compIdx >= 0 ? compIdx + 1 : 0) + 10);
        for (const line of window10) {
            if (line === title || line === company || skip.test(line)) continue;
            const firstPart = line.split(/\s*[·•]\s*/)[0].trim();
            if (firstPart && firstPart.length <= 60 && firstPart !== title && firstPart !== company && !skip.test(firstPart)) {
                if (locPat.test(firstPart) || firstPart === 'Remote' || firstPart === 'Worldwide') { location = firstPart; break; }
            }
        }
    }

    for (const el of document.querySelectorAll('button span, .job-details-jobs-unified-top-card__job-insight span')) {
        const t = el.innerText.trim();
        if (t === 'Remote' || t === 'Hybrid' || t === 'On-site') { workType = t; break; }
    }

    let description = '';
    for (const h2 of document.querySelectorAll('h2')) {
        if (h2.innerText.includes('About the job')) {
            const descSpan = h2.parentElement?.querySelector('span[class*="expandable"], div[class*="description"]');
            if (descSpan) { description = descSpan.innerHTML.trim(); break; }
        }
    }
    if (!description) {
        const bodyText = document.body.innerText;
        const idx = bodyText.indexOf('About the job');
        if (idx !== -1) {
            let content = bodyText.substring(idx + 13);
            let stopIdx = content.length;
            for (const m of ['About the company', 'Similar jobs', 'People also viewed']) {
                const i = content.indexOf(m);
                if (i !== -1 && i < stopIdx) stopIdx = i;
            }
            description = `<p>${content.substring(0, stopIdx).trim().replace(/\n/g, '<br>')}</p>`;
        }
    }

    return { title, company, location, workType, description, url: window.location.href, scrapedAt: new Date().toISOString(), source: 'visual-fallback' };
}

// ─── PROFILE SCRAPING ────────────────────────────────────────────────────────

function scrapeProfileDetails() {
    console.log('JobOS: Starting profile scrape...');

    const name = document.querySelector('h1')?.innerText?.trim() || '';

    const headlineEl = document.querySelector('.text-body-medium.break-words') ||
        document.querySelector('[data-generated-suggestion-target] .text-body-medium');
    const headline = headlineEl?.innerText?.trim() || '';

    const locationEl = document.querySelector('.text-body-small.inline.t-black--light.break-words') ||
        document.querySelector('.pv-text-details__left-panel .t-black--light');
    const location = locationEl?.innerText?.trim() || '';

    let summary = '';
    for (const section of document.querySelectorAll('section')) {
        for (const h of section.querySelectorAll('h2, h3')) {
            if (h.innerText.trim().toLowerCase() === 'about') {
                const textEl = section.querySelector('.inline-show-more-text span[aria-hidden="true"], .pv-shared-text-with-see-more span[aria-hidden="true"]');
                if (textEl) { summary = textEl.innerText.trim(); break; }
                for (const sp of section.querySelectorAll('span[aria-hidden="true"]')) {
                    if (sp.innerText.trim().length > 50) { summary = sp.innerText.trim(); break; }
                }
            }
        }
        if (summary) break;
    }

    const skills = [];
    for (const el of document.querySelectorAll('[data-view-name="profile-component-entity"] .t-bold span[aria-hidden="true"]')) {
        const t = el.innerText.trim();
        if (t && skills.length < 20) skills.push(t);
    }

    // Build structured raw text for AI parsing
    const rawText = [
        `Name: ${name}`,
        `Headline: ${headline}`,
        `Location: ${location}`,
        summary ? `\nAbout:\n${summary}` : '',
        skills.length ? `\nSkills:\n${skills.join(', ')}` : '',
        '\n--- Page text for context ---',
        document.body.innerText.substring(0, 3000)
    ].filter(Boolean).join('\n');

    return { name, headline, location, summary, skills, rawText };
}

// ─── PAGE TYPE DETECTION ──────────────────────────────────────────────────────

function isScrapableJobPage() {
    const url = window.location.href;
    return url.includes('/jobs/view/') ||
        (url.includes('/jobs/collections/') && url.includes('currentJobId')) ||
        (url.includes('/jobs/search/') && url.includes('currentJobId'));
}

function isOwnProfilePage() {
    if (!/linkedin\.com\/in\/[^/?]+/.test(window.location.href)) return false;
    return !!(
        document.querySelector('a[href*="/edit/forms/intro"]') ||
        document.querySelector('[data-view-name="profile-card-edit-cta"]') ||
        Array.from(document.querySelectorAll('button')).some(b =>
            b.innerText.includes('Add profile section') || b.innerText.includes('Open to')
        )
    );
}

// ─── BUTTON INJECTION ─────────────────────────────────────────────────────────

function injectJobButton() {
    if (document.getElementById('jobos-save-btn')) return;
    if (!isScrapableJobPage()) return;

    const btn = document.createElement('button');
    btn.id = 'jobos-save-btn';
    btn.innerHTML = '<span>+</span> Save to JobOS';
    Object.assign(btn.style, {
        position: 'fixed', bottom: '20px', right: '20px', zIndex: '9999',
        padding: '12px 24px', backgroundColor: '#0f172a', color: 'white',
        border: 'none', borderRadius: '50px', cursor: 'pointer',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)', fontSize: '14px', fontWeight: '600',
        display: 'flex', alignItems: 'center', gap: '8px',
        fontFamily: '-apple-system, system-ui, sans-serif'
    });

    btn.onclick = async () => {
        const orig = btn.innerHTML;
        try { chrome.runtime.getURL(''); } catch { alert('Please REFRESH (F5)'); return; }
        btn.innerText = 'Scanning...';
        btn.style.backgroundColor = '#64748b';
        try {
            const jobData = scrapeJobDetails();
            const descPreview = jobData.description.replace(/<[^>]*>/g, '').substring(0, 80) + '...';
            if (!confirm(`JobOS Found:\n\nTitle: ${jobData.title}\nCompany: ${jobData.company}\nLocation: ${jobData.location}\n\nDescription: ${jobData.description.length} chars\n"${descPreview}"\n\nSave?`)) {
                btn.innerHTML = orig; btn.style.backgroundColor = '#0f172a'; return;
            }
            if (!jobData.title) throw new Error('Missing Job Title');
            btn.innerText = 'Saving...';
            const response = await chrome.runtime.sendMessage({ action: 'save_job', data: jobData });
            if (response.success) {
                btn.innerHTML = response.data?.isDuplicate ? '<span>⚠️</span> Duplicate' : '<span>✓</span> Saved!';
                btn.style.backgroundColor = response.data?.isDuplicate ? '#eab308' : '#10b981';
                setTimeout(() => { btn.innerHTML = orig; btn.style.backgroundColor = '#0f172a'; }, 3000);
            } else throw new Error(response.error || 'Server error');
        } catch (error) {
            btn.innerText = 'Error!';
            btn.style.backgroundColor = '#ef4444';
            alert(`Failed: ${error.message}\n\nCheck console (F12) for details.`);
            setTimeout(() => { btn.innerHTML = orig; btn.style.backgroundColor = '#0f172a'; }, 3000);
        }
    };

    document.body.appendChild(btn);
}

function injectProfileButton() {
    if (document.getElementById('jobos-profile-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'jobos-profile-btn';
    btn.innerHTML = '👤 Save Profile to JobOS';
    Object.assign(btn.style, {
        position: 'fixed', bottom: '20px', right: '20px', zIndex: '9999',
        padding: '12px 24px', backgroundColor: '#0369a1', color: 'white',
        border: 'none', borderRadius: '50px', cursor: 'pointer',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)', fontSize: '14px', fontWeight: '600',
        display: 'flex', alignItems: 'center', gap: '8px',
        fontFamily: '-apple-system, system-ui, sans-serif'
    });

    btn.onclick = async () => {
        const orig = btn.innerHTML;
        try { chrome.runtime.getURL(''); } catch { alert('Please REFRESH (F5)'); return; }
        btn.innerText = 'Reading profile...';
        btn.style.backgroundColor = '#64748b';
        try {
            const profileData = scrapeProfileDetails();
            if (!profileData.name) throw new Error('Could not read your name. Make sure you are on your own LinkedIn profile page.');
            btn.innerText = 'Saving to JobOS...';
            const response = await chrome.runtime.sendMessage({ action: 'save_profile', data: profileData });
            if (response.success) {
                btn.innerHTML = '<span>✓</span> Profile Saved!';
                btn.style.backgroundColor = '#0369a1';
                setTimeout(() => { btn.innerHTML = orig; btn.style.backgroundColor = '#0369a1'; }, 3000);
            } else throw new Error(response.error || 'Server error');
        } catch (error) {
            btn.innerText = 'Error!';
            btn.style.backgroundColor = '#ef4444';
            alert(`Failed to save profile: ${error.message}`);
            setTimeout(() => { btn.innerHTML = orig; btn.style.backgroundColor = '#0369a1'; }, 3000);
        }
    };

    document.body.appendChild(btn);
}

// ─── ORCHESTRATION ────────────────────────────────────────────────────────────

function removeAllButtons() {
    document.getElementById('jobos-save-btn')?.remove();
    document.getElementById('jobos-profile-btn')?.remove();
}

function tryInject(maxAttempts = 12, delay = 500) {
    let attempts = 0;
    function attempt() {
        attempts++;
        if (isScrapableJobPage()) { injectJobButton(); return; }
        if (isOwnProfilePage()) { injectProfileButton(); return; }
        if (attempts < maxAttempts) setTimeout(attempt, delay);
    }
    attempt();
}

// ─── MESSAGE LISTENER ─────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'scrape') sendResponse(scrapeJobDetails());
    else if (request.action === 'scrape_profile') sendResponse(scrapeProfileDetails());
});

// ─── INIT & SPA NAVIGATION ────────────────────────────────────────────────────

tryInject();

let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        removeAllButtons();
        tryInject();
    }
}).observe(document, { subtree: true, childList: true });
