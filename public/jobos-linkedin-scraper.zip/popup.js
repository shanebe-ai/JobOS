document.addEventListener('DOMContentLoaded', async () => {
    const saveJobBtn = document.getElementById('saveJobBtn');
    const saveProfileBtn = document.getElementById('saveProfileBtn');
    const statusDiv = document.getElementById('status');

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = tab.url || '';

    const isJobPage = url.includes('linkedin.com/jobs/view') ||
        (url.includes('linkedin.com/jobs/') && url.includes('currentJobId'));
    const isProfilePage = /linkedin\.com\/in\/[^/?]+/.test(url);

    // Highlight the relevant button based on current page
    if (!isJobPage) saveJobBtn.style.opacity = '0.45';
    if (!isProfilePage) saveProfileBtn.style.opacity = '0.45';

    function setStatus(msg, type = '') {
        statusDiv.textContent = msg;
        statusDiv.className = 'status ' + type;
    }

    // ─── Save Job ────────────────────────────────────────────────────────────
    saveJobBtn.addEventListener('click', async () => {
        if (!isJobPage) {
            setStatus('Navigate to a LinkedIn job posting first.', 'error');
            return;
        }
        setStatus('Scanning job...');
        saveJobBtn.disabled = true;

        try {
            const scrapeResult = await chrome.tabs.sendMessage(tab.id, { action: 'scrape' });
            if (!scrapeResult?.title) throw new Error('Could not read job details from this page.');

            setStatus('Saving...');
            const saveResult = await chrome.runtime.sendMessage({ action: 'save_job', data: scrapeResult });

            if (saveResult.success) {
                setStatus(saveResult.data?.isDuplicate ? '⚠️ Already in your board.' : '✓ Job saved to JobOS!', 'success');
            } else {
                throw new Error(saveResult.error || 'Unknown error');
            }
        } catch (error) {
            setStatus('Error: ' + error.message, 'error');
        } finally {
            saveJobBtn.disabled = false;
        }
    });

    // ─── Save Profile ────────────────────────────────────────────────────────
    saveProfileBtn.addEventListener('click', async () => {
        if (!isProfilePage) {
            setStatus('Navigate to your LinkedIn profile first.', 'error');
            return;
        }
        setStatus('Reading profile...');
        saveProfileBtn.disabled = true;

        try {
            const profileResult = await chrome.tabs.sendMessage(tab.id, { action: 'scrape_profile' });
            if (!profileResult?.name) throw new Error('Could not read profile. Make sure you are on your own profile page.');

            setStatus('Parsing with AI...');
            const saveResult = await chrome.runtime.sendMessage({ action: 'save_profile', data: profileResult });

            if (saveResult.success) {
                setStatus('✓ Profile saved to JobOS!', 'success');
            } else {
                throw new Error(saveResult.error || 'Unknown error');
            }
        } catch (error) {
            setStatus('Error: ' + error.message, 'error');
        } finally {
            saveProfileBtn.disabled = false;
        }
    });
});
