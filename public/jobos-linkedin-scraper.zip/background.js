// LinkedIn for JobOS - Background Script

const API_BASE = 'http://37.27.80.77:3002';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'save_job') {
        saveJob(request.data)
            .then(result => sendResponse(result))
            .catch(error => sendResponse({ success: false, error: error.message }));
        return true;
    }
    if (request.action === 'save_profile') {
        saveProfile(request.data)
            .then(result => sendResponse(result))
            .catch(error => sendResponse({ success: false, error: error.message }));
        return true;
    }
});

async function saveJob(jobData) {
    try {
        const response = await fetch(`${API_BASE}/api/jobs`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(jobData)
        });
        if (!response.ok) throw new Error(`Server error: ${response.status} ${response.statusText}`);
        const result = await response.json();
        return { success: true, data: result };
    } catch (error) {
        console.error('JobOS: Error saving job:', error);
        return { success: false, error: error.message };
    }
}

async function saveProfile(profileData) {
    try {
        const response = await fetch(`${API_BASE}/api/profile`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rawText: profileData.rawText })
        });
        if (!response.ok) throw new Error(`Server error: ${response.status} ${response.statusText}`);
        const result = await response.json();
        return { success: true, data: result };
    } catch (error) {
        console.error('JobOS: Error saving profile:', error);
        return { success: false, error: error.message };
    }
}
